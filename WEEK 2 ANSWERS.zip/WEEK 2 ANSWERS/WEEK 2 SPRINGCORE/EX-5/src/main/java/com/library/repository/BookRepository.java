package com.library.repository;

public class BookRepository {

    public void accessData() {
        System.out.println("Accessing data from the repository...");
    }
}
