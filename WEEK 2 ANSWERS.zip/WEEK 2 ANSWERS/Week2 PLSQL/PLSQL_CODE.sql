use shruti1;
CREATE TABLE customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    age INT,
    balance DECIMAL(15, 2),
    IsVIP BOOLEAN DEFAULT FALSE
);

CREATE TABLE loans (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    loan_amount DECIMAL(15, 2),
    interest_rate DECIMAL(5, 2),
    loan_due_date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);
DELIMITER //

CREATE PROCEDURE ApplyInterestRateDiscount()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_customer_id INT;
    DECLARE v_current_interest_rate DECIMAL(5,2);

    DECLARE cur CURSOR FOR
        SELECT l.customer_id, l.interest_rate
        FROM loans l
        JOIN customers c ON l.customer_id = c.customer_id
        WHERE c.age > 60;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO v_customer_id, v_current_interest_rate;
        IF done THEN
            LEAVE read_loop;
        END IF;

        UPDATE loans
        SET interest_rate = interest_rate - 0.01
        WHERE customer_id = v_customer_id;
    END LOOP;

    CLOSE cur;
END//

DELIMITER ;

CALL ApplyInterestRateDiscount();

DELIMITER //

CREATE PROCEDURE PromoteToVIP()
BEGIN
    UPDATE customers
    SET IsVIP = TRUE
    WHERE balance > 10000;
END//

DELIMITER ;

CALL PromoteToVIP();

DELIMITER //
CREATE PROCEDURE SendLoanReminders()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_customer_id INT;
    DECLARE v_loan_due_date DATE;
	DECLARE cur CURSOR FOR
        SELECT customer_id, loan_due_date
        FROM loans
        WHERE loan_due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY);

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;
     read_loop: LOOP
        FETCH cur INTO v_customer_id, v_loan_due_date;
        IF done THEN
            LEAVE read_loop;
        END IF;
       SELECT CONCAT('Reminder: Loan for customer ID ', v_customer_id, ' is due on ', v_loan_due_date) AS ReminderMessage;
    END LOOP;
    CLOSE cur;
END//
DELIMITER ;

CALL SendLoanReminders();

CREATE TABLE Accounts (
    AccountID int PRIMARY KEY,
    Balance int
);
CREATE TABLE Employees (
    EmployeeID int PRIMARY KEY,
    Salary int
);




DELIMITER //

CREATE PROCEDURE SafeTransferFunds(
    IN p_from_account INT,
    IN p_to_account INT,
    IN p_amount DECIMAL(10, 2)
)
BEGIN
    DECLARE v_balance DECIMAL(10, 2);

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' -- No Data Found
    BEGIN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Account does not exist';
    END;
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Transaction failed';
    END;

    START TRANSACTION;
    SELECT Balance INTO v_balance
    FROM Accounts
    WHERE AccountID = p_from_account
    FOR UPDATE;

    IF v_balance IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Account does not exist';
    ELSEIF v_balance < p_amount THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient funds in the source account';
    END IF;

    UPDATE Accounts
    SET Balance = Balance - p_amount
    WHERE AccountID = p_from_account;

    UPDATE Accounts
    SET Balance = Balance + p_amount
    WHERE AccountID = p_to_account;

    COMMIT;
END //

DELIMITER ;

DELIMITER //
CREATE PROCEDURE UpdateSalary(
    IN p_employee_id INT,
    IN p_increase_percentage DECIMAL(5, 2)
)
BEGIN
    DECLARE v_row_count INT;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Transaction failed';
    END;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' -- No Data Found
    BEGIN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Employee ID does not exist';
    END;

    START TRANSACTION;

    UPDATE Employees
    SET Salary = Salary * (1 + p_increase_percentage / 100)
    WHERE EmployeeID = p_employee_id;

    GET DIAGNOSTICS v_row_count = ROW_COUNT;

    IF v_row_count = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error: Employee ID does not exist';
    END IF;

    COMMIT;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE AddNewCustomer(
    IN p_customer_id INT,
    IN p_name VARCHAR(100),
    IN p_dob DATE,
    IN p_balance DECIMAL(10, 2)
)
BEGIN

    DECLARE CONTINUE HANDLER FOR SQLSTATE '23000' 
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Error: Customer ID already exists';
    END;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'An unexpected error occurred';
    END;

    START TRANSACTION;

    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
    VALUES (p_customer_id, p_name, p_dob, p_balance, NOW());

    COMMIT;
END //

DELIMITER ;

DELIMITER //

CREATE PROCEDURE ProcessMonthlyInterest()
BEGIN
    UPDATE Accounts
    SET Balance = Balance * 1.01;
END //

DELIMITER ;


DESCRIBE Accounts;


DELIMITER //
CREATE PROCEDURE UpdateEmployeeBonus(
    IN p_department VARCHAR(50),
    IN p_bonus_percentage DECIMAL(5,2)
)
BEGIN
    UPDATE Employees
    SET Salary = Salary * (1 + p_bonus_percentage / 100)
    WHERE Department = p_department;

    IF ROW_COUNT() = 0 THEN
        SELECT 'No employees found in the specified department' AS Message;
    END IF;
END //

DELIMITER ;




DELIMITER //

CREATE PROCEDURE UpdateEmployeeBonus(
    IN p_department VARCHAR(50),
    IN p_bonus_percentage DECIMAL(5,2)
)
BEGIN
    UPDATE Employees
    SET Salary = Salary * (1 + p_bonus_percentage / 100)
    WHERE Department = p_department;

    IF ROW_COUNT() = 0 THEN
        SELECT 'No employees found in the specified department' AS Message;
    END IF;
END //

DELIMITER ;

ALTER TABLE Employees ADD COLUMN Department VARCHAR(50);

CALL ProcessMonthlyInterest();
CALL UpdateEmployeeBonus('HR', 10.00);
CALL TransferFunds(1, 2, 500.00);


DELIMITER //
CREATE FUNCTION CalculateAge(p_dob DATE) 
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE v_age INT;
    SET v_age = TIMESTAMPDIFF(YEAR, p_dob, CURDATE());
    RETURN v_age;
END //
DELIMITER ;

SELECT CalculateAge('1985-05-15') AS Age;


DELIMITER //
CREATE FUNCTION CalculateMonthlyInstallment(p_loan_amount DECIMAL(15,2), 
                                             p_interest_rate DECIMAL(5,2), 
                                             p_loan_duration INT) 
RETURNS DECIMAL(15,2)
DETERMINISTIC
BEGIN
    DECLARE v_monthly_payment DECIMAL(15,2);
    DECLARE v_monthly_rate DECIMAL(5,2);
    DECLARE v_num_payments INT;
    
    SET v_monthly_rate = p_interest_rate / 100 / 12;
    SET v_num_payments = p_loan_duration * 12;
	IF v_monthly_rate = 0 THEN
        SET v_monthly_payment = p_loan_amount / v_num_payments;
    ELSE
        SET v_monthly_payment = p_loan_amount * (v_monthly_rate / (1 - POW(1 + v_monthly_rate, -v_num_payments)));
    END IF;
    RETURN v_monthly_payment;
END //
DELIMITER ;
SELECT CalculateMonthlyInstallment(10000, 5, 10) AS MonthlyInstallment;

DELIMITER //
CREATE FUNCTION HasSufficientBalance(p_account_id INT, 
                                      p_amount DECIMAL(15,2)) 
RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    DECLARE v_balance DECIMAL(15,2);
    SELECT Balance INTO v_balance
    FROM Accounts
    WHERE AccountID = p_account_id;
    RETURN (v_balance >= p_amount);
END //
DELIMITER ;

ALTER TABLE Customers
ADD COLUMN LastModified DATETIME;

DELIMITER //

CREATE TRIGGER UpdateCustomerLastModified
BEFORE UPDATE ON Customers
FOR EACH ROW
BEGIN
    SET NEW.LastModified = NOW();
END //

DELIMITER ;
UPDATE Customers
SET Name = 'New Name'
WHERE Customer_ID = 1;

CREATE TABLE AuditLog (
    LogID INT AUTO_INCREMENT PRIMARY KEY,
    TransactionID INT,
    ActionDate DATETIME,
    ActionType VARCHAR(50),
    Details TEXT
);

CREATE TABLE Transactions (
    TransactionID INT AUTO_INCREMENT PRIMARY KEY,
    AccountID INT,
    TransactionDate DATETIME,
    Amount DECIMAL(10, 2),
    TransactionType VARCHAR(10)
);
DELIMITER //
CREATE TRIGGER LogTransaction
AFTER INSERT ON Transactions
FOR EACH ROW
BEGIN
    INSERT INTO AuditLog (TransactionID, ActionDate, ActionType, Details)
    VALUES (NEW.TransactionID, NOW(), 'INSERT', 
            CONCAT('Inserted transaction: ', 'AccountID=', NEW.AccountID, ', Amount=', NEW.Amount, ', Type=', NEW.TransactionType));
END //

DELIMITER ;
INSERT INTO Transactions (AccountID, TransactionDate, Amount, TransactionType)
VALUES (1, NOW(), 100, 'Deposit');


DELIMITER //
CREATE TRIGGER CheckTransactionRules
BEFORE INSERT ON Transactions
FOR EACH ROW
BEGIN
    DECLARE v_balance DECIMAL(15,2);
    SELECT Balance INTO v_balance
    FROM Accounts
    WHERE AccountID = NEW.AccountID;
    IF NEW.TransactionType = 'Withdrawal' AND NEW.Amount > v_balance THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient balance for withdrawal';
    END IF;
    IF NEW.TransactionType = 'Deposit' AND NEW.Amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Deposit amount must be positive';
    END IF;
END //
DELIMITER ;
INSERT INTO Transactions (AccountID, TransactionDate, Amount, TransactionType)
VALUES (1, NOW(), 2000, 'Withdrawal');
INSERT INTO Transactions (AccountID, TransactionDate, Amount, TransactionType)
VALUES (1, NOW(), 100, 'Deposit');


DELIMITER //
CREATE PROCEDURE GenerateMonthlyStatements()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_customer_id INT;
    DECLARE v_name VARCHAR(100);
    DECLARE v_transaction_date DATE;
    DECLARE v_amount DECIMAL(10,2);
    DECLARE v_transaction_type VARCHAR(10);

    DECLARE cur CURSOR FOR
        SELECT c.CustomerID, c.Name, t.TransactionDate, t.Amount, t.TransactionType
        FROM Customers c
        JOIN Accounts a ON c.CustomerID = a.CustomerID
        JOIN Transactions t ON a.AccountID = t.AccountID
        WHERE MONTH(t.TransactionDate) = MONTH(CURDATE())
          AND YEAR(t.TransactionDate) = YEAR(CURDATE());
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur;
	read_loop: LOOP
        FETCH cur INTO v_customer_id, v_name, v_transaction_date, v_amount, v_transaction_type;
        IF done THEN
            LEAVE read_loop;
        END IF;
    END LOOP;
    CLOSE cur;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE ApplyAnnualFee()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_account_id INT;
    DECLARE v_balance DECIMAL(10,2);
    DECLARE annual_fee DECIMAL(10,2) DEFAULT 50; -- Example fee amount
    DECLARE cur CURSOR FOR
        SELECT AccountID, Balance FROM Accounts;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_account_id, v_balance;
        IF done THEN
            LEAVE read_loop;
        END IF;
        UPDATE Accounts
        SET Balance = v_balance - annual_fee
        WHERE AccountID = v_account_id;
    END LOOP;
    CLOSE cur;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE UpdateLoanInterestRates()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_loan_id INT;
    DECLARE v_interest_rate DECIMAL(5,2);
    DECLARE new_interest_rate DECIMAL(5,2) DEFAULT 6; -- Example new interest rate
    DECLARE cur CURSOR FOR
        SELECT LoanID, InterestRate FROM Loans;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_loan_id, v_interest_rate;
        IF done THEN
            LEAVE read_loop;
        END IF;
        UPDATE Loans
        SET InterestRate = new_interest_rate
        WHERE LoanID = v_loan_id;
    END LOOP;
    CLOSE cur;
    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE AddNewCustomer(
    IN p_customer_id INT,
    IN p_name VARCHAR(255),
    IN p_dob DATE,
    IN p_balance DECIMAL(10,2)
)
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;

    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
    VALUES (p_customer_id, p_name, p_dob, p_balance, NOW());

    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE UpdateCustomerDetails(
    IN p_customer_id INT,
    IN p_name VARCHAR(255),
    IN p_dob DATE
)
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;

    UPDATE Customers
    SET Name = p_name, DOB = p_dob, LastModified = NOW()
    WHERE CustomerID = p_customer_id;

    COMMIT;
END //

DELIMITER ;



DELIMITER //

CREATE FUNCTION GetCustomerBalance(p_customer_id INT)
RETURNS DECIMAL(10,2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_balance DECIMAL(10,2);

    SELECT Balance INTO v_balance
    FROM Customers
    WHERE CustomerID = p_customer_id;

    RETURN v_balance;
END //

DELIMITER ;

DELIMITER //
CREATE PROCEDURE HireNewEmployee(
    IN p_employee_id INT,
    IN p_name VARCHAR(255),
    IN p_salary DECIMAL(10,2),
    IN p_department VARCHAR(255)
)
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;
    START TRANSACTION;

    INSERT INTO Employees (EmployeeID, Name, Salary, Department, HireDate)
    VALUES (p_employee_id, p_name, p_salary, p_department, NOW());
    COMMIT;
END //

DELIMITER ;

DELIMITER //
CREATE PROCEDURE UpdateEmployeeDetails(
    IN p_employee_id INT,
    IN p_name VARCHAR(255),
    IN p_salary DECIMAL(10,2),
    IN p_department VARCHAR(255)
)
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;
    UPDATE Employees
    SET Name = p_name, Salary = p_salary, Department = p_department
    WHERE EmployeeID = p_employee_id;
    COMMIT;
END //
DELIMITER ;

DELIMITER //

CREATE FUNCTION CalculateAnnualSalary(p_employee_id INT)
RETURNS DECIMAL(10,2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_salary DECIMAL(10,2);

    SELECT Salary INTO v_salary
    FROM Employees
    WHERE EmployeeID = p_employee_id;

    RETURN v_salary * 12; 
END //

DELIMITER ;

DELIMITER //
CREATE PROCEDURE OpenNewAccount(
    IN p_customer_id INT,
    IN p_initial_balance DECIMAL(10,2)
)
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;

    INSERT INTO Accounts (CustomerID, Balance, CreationDate)
    VALUES (p_customer_id, p_initial_balance, NOW());

    COMMIT;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE CloseAccount(
    IN p_account_id INT
)
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;
    DELETE FROM Accounts
    WHERE AccountID = p_account_id;
    COMMIT;
END //
DELIMITER ;

DELIMITER //

CREATE FUNCTION GetTotalBalance(p_customer_id INT)
RETURNS DECIMAL(10,2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE v_total_balance DECIMAL(10,2);

    SELECT SUM(Balance) INTO v_total_balance
    FROM Accounts
    WHERE CustomerID = p_customer_id;

    RETURN IFNULL(v_total_balance, 0);
END //

DELIMITER ;











