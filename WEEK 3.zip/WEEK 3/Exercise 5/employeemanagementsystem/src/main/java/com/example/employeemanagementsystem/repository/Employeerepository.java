import javax.persistence.NamedQuery;
import org.springframework.data.jpa.repository.Query;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query(name = "Employee.findByName")
    List<Employee> findEmployeesByName(@Param("name") String name);

    
    @Query(name = "Employee.findByEmail")
    Employee findEmployeeByEmail(@Param("email") String email);

    @Query(name = "Employee.findByDepartmentId")
    List<Employee> findEmployeesByDepartmentId(@Param("departmentId") Long departmentId);
}
