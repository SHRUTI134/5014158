package com.example.employeemanagementsystem.entity;

public @interface Entity {

}
