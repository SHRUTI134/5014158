package com.example.employeemanagementsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.employeemanagementsystem.entity.Department;

import java.util.List; // Import the List class

@Repository
public interface Departmentrepository extends JpaRepository<Department, Long> {

    List<Department> findByName(String name);
}
