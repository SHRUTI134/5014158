package com.example.employeemanagementsystem.controller;

public @interface DeleteMapping {

    String value();

}
