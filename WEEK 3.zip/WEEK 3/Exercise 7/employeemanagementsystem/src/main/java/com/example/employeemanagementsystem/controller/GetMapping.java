package com.example.employeemanagementsystem.controller;

public @interface GetMapping {

    String value();

}
