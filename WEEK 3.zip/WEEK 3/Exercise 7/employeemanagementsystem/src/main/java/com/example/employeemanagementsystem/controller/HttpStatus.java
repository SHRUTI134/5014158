package com.example.employeemanagementsystem.controller;

public class HttpStatus {

    public static final String CREATED = null;

}
