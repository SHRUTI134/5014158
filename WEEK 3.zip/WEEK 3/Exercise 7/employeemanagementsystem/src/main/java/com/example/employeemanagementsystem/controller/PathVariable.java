package com.example.employeemanagementsystem.controller;

public @interface PathVariable {

}
