package com.example.employeemanagementsystem.controller;

public @interface RequestBody {

}
