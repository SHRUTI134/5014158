package com.example.employeemanagementsystem.controller;

public @interface RequestMapping {

    String value();

}
