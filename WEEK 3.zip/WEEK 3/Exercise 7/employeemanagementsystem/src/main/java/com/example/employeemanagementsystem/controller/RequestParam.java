package com.example.employeemanagementsystem.controller;

public @interface RequestParam {

    String defaultValue();

    boolean required();

}
