package com.example.employeemanagementsystem.controller;

import com.example.employeemanagementsystem.entity.Employee;

public class ResponseEntity<T> {

    public static Object ok(Employee updatedEmployee) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'ok'");
    }

    public static Object noContent() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'noContent'");
    }

}
