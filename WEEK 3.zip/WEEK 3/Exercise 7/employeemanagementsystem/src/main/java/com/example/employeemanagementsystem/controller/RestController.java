package com.example.employeemanagementsystem.controller;

public @interface RestController {

}
