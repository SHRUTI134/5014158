package com.example.employeemanagementsystem.controller;

import com.example.employeemanagementsystem.entity.Employee;

public class ResponseEntity<T> {

    public static Object ok(Employee updatedEmployee) {
        throw new UnsupportedOperationException("Unimplemented method 'ok'");
    }

    public static Object noContent() {
    
        throw new UnsupportedOperationException("Unimplemented method 'noContent'");
    }

}
