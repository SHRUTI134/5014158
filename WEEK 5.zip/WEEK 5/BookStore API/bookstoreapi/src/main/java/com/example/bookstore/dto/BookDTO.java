package com.example.bookstore.dto;

import org.springframework.hateoas.RepresentationModel;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BookDTO extends RepresentationModel<BookDTO> {
    @JsonProperty("id")
    private Long id;
    
    @JsonProperty("book_title")
    private String title;
    
    @JsonProperty("book_author")
    private String author;
    
    @JsonProperty("book_price")
    private Double price;
    
    @JsonProperty("book_isbn")
    private String isbn;
}
