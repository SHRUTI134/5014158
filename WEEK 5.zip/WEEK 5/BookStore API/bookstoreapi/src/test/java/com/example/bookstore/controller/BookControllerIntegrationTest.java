package com.example.bookstore.controller;

import com.example.bookstore.model.Book; 
import com.example.bookstore.repository.BookRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.transaction.annotation.Transactional;

import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
public class BookControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BookRepository bookRepository;

    @BeforeEach
    public void setup() {
        bookRepository.deleteAll();  
    }

    @Test
    public void testGetAllBooks() throws Exception {
        
        Book book1 = new Book();
        book1.setTitle("Book Title 1");
        book1.setAuthor("Author 1");
        book1.setPrice(10.0);
        book1.setIsbn("1234567890");
        
        Book book2 = new Book();
        book2.setTitle("Book Title 2");
        book2.setAuthor("Author 2");
        book2.setPrice(15.0);
        book2.setIsbn("0987654321");

        bookRepository.save(book1);
        bookRepository.save(book2);

        mockMvc.perform(get("/books").accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].title", is("Book Title 1")))
                .andExpect(jsonPath("$[1].title", is("Book Title 2")));
    }

    @Test
    public void testAddBook() throws Exception {
        String bookJson = "{\"title\":\"New Book\",\"author\":\"New Author\",\"price\":20.0,\"isbn\":\"1122334455\"}";

        ResultActions resultActions = mockMvc.perform(post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(bookJson))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.title", is("New Book")));

        long count = bookRepository.count();
        assert count == 1; 
    }

    @Test
    public void testGetBookById() throws Exception {
        Book book = new Book();
        book.setTitle("Existing Book");
        book.setAuthor("Author");
        book.setPrice(30.0);
        book.setIsbn("1234567890");
        book = bookRepository.save(book);

        mockMvc.perform(get("/books/" + book.getId()).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.title", is("Existing Book")));
    }
}
