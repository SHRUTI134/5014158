package com.example.bookstore.controller;

import com.example.bookstore.dto.BookDTO;
import com.example.bookstore.metrics.CustomMetrics;
import com.example.bookstore.service.BookService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;

import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BookController.class)
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookService bookService;

    @MockBean
    private CustomMetrics customMetrics;

    @Test
    public void testGetAllBooks() throws Exception {
        BookDTO book1 = new BookDTO(1L, "Book Title 1", "Author 1", 10.0, "1234567890");
        BookDTO book2 = new BookDTO(2L, "Book Title 2", "Author 2", 15.0, "0987654321");

        Mockito.when(bookService.getAllBooks()).thenReturn(Arrays.asList(book1, book2));

        mockMvc.perform(get("/books").accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$[0].title", is("Book Title 1")))
                .andExpect(jsonPath("$[1].title", is("Book Title 2")));
    }

    @Test
    public void testAddBook() throws Exception {
        BookDTO newBook = new BookDTO(null, "New Book", "New Author", 20.0, "1122334455");
        BookDTO savedBook = new BookDTO(1L, "New Book", "New Author", 20.0, "1122334455");

        Mockito.when(bookService.saveBook(Mockito.any(BookDTO.class))).thenReturn(savedBook);

        mockMvc.perform(post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"title\":\"New Book\",\"author\":\"New Author\",\"price\":20.0,\"isbn\":\"1122334455\"}"))
                .andExpect(status().isCreated())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.title", is("New Book")));
    }

    @Test
    public void testGetBookById() throws Exception {
        BookDTO book = new BookDTO(1L, "Existing Book", "Author", 30.0, "1234567890");

        Mockito.when(bookService.getBookById(1L)).thenReturn(book);

        mockMvc.perform(get("/books/1").accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.title", is("Existing Book")));
    }

}
